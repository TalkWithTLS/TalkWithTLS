/* opensslconf.h for openSSL */

#include <wolfssl/openssl/opensslconf.h>
