OpenSSL User Support resources
==============================

For *questions* on how to use OpenSSL or what went wrong when you
tried something, our primary resource is the mailing list
openssl-users@openssl.org, where you can get help from others in the
OpenSSL community (which includes the developers as time permits).

Only subscribers can post to openssl-users@openssl.org (although the
archives are public).
For more information, see https://www.openssl.org/community/mailinglists.html
